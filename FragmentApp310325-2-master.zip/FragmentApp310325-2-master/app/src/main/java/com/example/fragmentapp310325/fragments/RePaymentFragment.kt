package com.example.fragmentapp310325.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation
import com.example.fragmentapp310325.R
import com.example.fragmentapp310325.databinding.FragmentRePaymentBinding

class RePaymentFragment : Fragment() {

    private var _binding : FragmentRePaymentBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRePaymentBinding.inflate(layoutInflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) = with(binding) {
        super.onViewCreated(view, savedInstanceState)

        makeARePaymentBtn.setOnClickListener {
            Navigation
                .findNavController(requireView())
                .navigate(RePaymentFragmentDirections
                    .actionRePaymentFragmentToMakeARePaymentFragment())
        }

        drawDownFundsBtn.setOnClickListener {

            val fundString = fundsET.text.toString()

            Navigation.findNavController(requireView())
                .navigate(RePaymentFragmentDirections
                    .actionRePaymentFragmentToDrawFundsFragment(fundString))
        }
    }

    companion object {
        @JvmStatic
        fun newInstance() =
            RePaymentFragment()
    }
}